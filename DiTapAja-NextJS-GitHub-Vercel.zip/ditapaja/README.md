# DiTapAja

Landing page SaaS NFC Review Card, dibuat dengan Next.js, TypeScript, Tailwind CSS, dan Lucide.

## Menjalankan di komputer
1. Install Node.js versi LTS dari https://nodejs.org
2. Ekstrak project.
3. Buka terminal di folder project.
4. Jalankan `npm install`
5. Jalankan `npm run dev`
6. Buka http://localhost:3000

## Deploy melalui GitHub + Vercel
1. Buat repository baru bernama `ditapaja` di https://github.com/new
2. Upload seluruh isi folder project ini ke repository (bisa lewat tombol Add file > Upload files).
3. Buka https://vercel.com/new
4. Hubungkan akun GitHub, pilih repository `ditapaja`.
5. Framework akan terdeteksi sebagai Next.js. Biarkan Build Command dan Output Directory default.
6. Klik Deploy.

Setelah terhubung, setiap perubahan yang di-push ke branch utama akan memicu deployment otomatis.

## Catatan
Ini adalah landing page frontend tahap awal. Form CTA masih berupa interaksi demo dan belum mengirim data ke backend. Sistem login, dashboard pelanggan, database, pemetaan UID NFC, tracking tap, pembayaran, dan integrasi Google Maps akan dibangun pada tahap berikutnya.
